let carts = document.querySelectorAll('.btn btn-primary py-3 px-5');

let products = [
    {
    	name:'Sudbina',
    	tag:'Sudbina',
    	price:800,
    	inCart: 0
    },
     {
    	name:'Vihor',
    	tag:'Vihor',
    	price:1000,
    	inCart: 0
    },
     {
    	name:'Grasac',
    	tag:'grasac',
    	price:900,
    	inCart: 0
    },
     {
    	name:'Vihor19',
    	tag:'vihor2',
    	price:1200,
    	inCart: 0
    }
]

for (let i=0; i<carts.length; i++) {
	carts[i].addEventListener('click',()=>{
		cartNumbers(products[i]);
		totalCost(products[i]);
	})
}

function onLoadCartNumbers(){
	let productNumbers=localStorage.getItem('cartNumbers');
	if (productNumbers) {
		document.querySelector('.cart span').textContent = productNumbers;
	}
}




function cartNumbers(products) {

	let productNumbers=localStorage.getItem('cartNumbers');
	
    
    productNumbers=parseInt(productNumbers);

    if (productNumbers) {
    	localStorage.setItem('cartNumbers', productNumbers + 1);
    	document.querySelector('.cart span').textContent = productNumbers + 1;
    }else{
    	localStorage.setItem('cartNumbers', 1);
    	document.querySelector('.cart span').textContent = 1;
    }
    setItems(products);
}

function setItems(products){
	let cartItems = localStorage.getItem('productsInCart');
	cartItems = JSON.parse(cartItems);
	

	if (cartItems != null) {
		if (cartItems[products.tag] == undefined) {
			cartItems = {
				...cartItems,
				[products.tag]:products
			}
		}
		cartItems[products.tag].inCart += 1;
	}else{
		products.inCart = 1;

    cartItems = {
		[products.tag]: products
	     }
    }

	
	localStorage.setItem("productsInCart", JSON.stringify(cartItems));
}

function totalCost(products) {
	//console.log("of the product price is",products.price);
	let cartCost = localStorage.getItem('totalCost');

	console.log("My cart cost is",cartCost);
	console.log(typeof cartCost);
	
	if (cartCost != null) {
		cartCost = parseInt(cartCost);
		localStorage.setItem("totalCost", cartCost + products.price);

	}else{
		localStorage.setItem("totalCost", products.price);

	}
}

function displayCart(){
	let cartItems = localStorage.getItem("productsInCart");
	cartItems = JSON.parse(cartItems);
	let productContainer = document.querySelector(".tabela");
	let cartCost = localStorage.getItem('totalCost');
    
    console.log(cartItems);
	if(cartItems && productContainer) {
		productContainer.innerHTML = '';
		Object.values(cartItems).map(item => {
			productContainer.innerHTML +=
			 `
			
		<table class="tabela">
		<tr class="naslov1">
			<th>Product</th>
			<th>Quantity</th>
			<th>Subtotal</th>
		</tr>
		<tr class="product">
			<td class="prvo">
				<div class="cart-info">
				    <a href=""><i class="fa fa-trash"></i></a>
					<img src="images/${item.tag}.png">

					<div>
						<p>${item.name}</p>
						<small>${item.price},00 Rsd</small>
						<br>
						
					</div>

				</div>
			</td>
			<td class="drugo">
			     <input type = 'number' value = '${item.inCart}'>
			</td>
			<td class="trece">${item.inCart*item.price},00 Rsd</td>
		</tr>
		
	</table>
		
			`;
		});

		productContainer.innerHTML +=`
		<div class="total-price">
		<h4>Total:</h4>
		<br>
		<h5>${cartCost},00 Rsd</h5>
	</div>

		`

	}
}



onLoadCartNumbers();
displayCart();
